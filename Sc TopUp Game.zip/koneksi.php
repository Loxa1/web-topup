<?php 

$koneksi = mysqli_connect("localhost","root","","ziptatop_d");

